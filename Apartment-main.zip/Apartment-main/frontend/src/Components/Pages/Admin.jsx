import React, { useState, useEffect, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { FaUsers, FaCreditCard, FaSignOutAlt, FaChartBar, FaCog, FaHome } from 'react-icons/fa';
import { motion } from 'framer-motion';

const Admin = () => {
  const { user, logout, isAuthenticated } = useContext(AuthContext);
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalPayments: 0,
    totalRevenue: 0,
    pendingPayments: 0
  });

  // Check if user is admin
  useEffect(() => {
    if (!isAuthenticated()) {
      navigate('/login');
      return;
    }

    // Check if user is admin (email contains 'admin')
    if (!user?.gmail?.toLowerCase().includes('admin')) {
      navigate('/');
      return;
    }

    // Fetch admin statistics
    fetchAdminStats();
  }, [user, isAuthenticated, navigate]);

  const fetchAdminStats = async () => {
    try {
      // Fetch users count
      const usersResponse = await fetch('http://localhost:4000/api/users');
      const usersData = await usersResponse.json();
      
      // Fetch payments count
      const paymentsResponse = await fetch('http://localhost:4000/api/payments');
      const paymentsData = await paymentsResponse.json();

      const totalUsers = usersData.users?.length || 0;
      const totalPayments = paymentsData.payments?.length || 0;
      const completedPayments = paymentsData.payments?.filter(p => p.status === 'completed') || [];
      const pendingPayments = paymentsData.payments?.filter(p => p.status === 'pending') || [];
      const totalRevenue = completedPayments.reduce((sum, payment) => sum + payment.amount, 0);

      setStats({
        totalUsers,
        totalPayments,
        totalRevenue,
        pendingPayments: pendingPayments.length
      });
    } catch (error) {
      console.error('Error fetching admin stats:', error);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const adminCards = [
    {
      title: 'Total Users',
      value: stats.totalUsers,
      icon: FaUsers,
      color: 'bg-yellow-400',
      link: '/users'
    },
    {
      title: 'Total Payments',
      value: stats.totalPayments,
      icon: FaCreditCard,
      color: 'bg-yellow-400',
      link: '/payment-records'
    },
    {
      title: 'Total Revenue',
      value: `$${stats.totalRevenue.toFixed(2)}`,
      icon: FaChartBar,
      color: 'bg-yellow-400',
      link: '/payment-records'
    },
    {
      title: 'Pending Payments',
      value: stats.pendingPayments,
      icon: FaCog,
      color: 'bg-yellow-400',
      link: '/payment-records'
    }
  ];

  return (
    <div className="min-h-screen bg-black">
      {/* Admin Header */}
      <div className="bg-yellow-400 text-black shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center">
                <FaHome className="w-6 h-6 text-yellow-400" />
              </div>
              <div>
                <h1 className="text-2xl text-black font-bold">HeavenPin Admin</h1>
                <p className="text-gray-800 text-sm">Administrative Dashboard</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-800">Welcome,</p>
                <p className="font-medium">{user?.name || 'Admin'}</p>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 bg-black hover:bg-gray-800 text-yellow-400 px-4 py-2 rounded-lg transition-colors"
              >
                <FaSignOutAlt className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Admin Navigation */}
      <div className="bg-white shadow-sm border-b border-yellow-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-8 py-4">
            <Link
              to="/users"
              className="flex items-center space-x-2 text-black  px-3 py-2 rounded-md text-sm font-medium transition-colors"
            >
              <FaUsers className="w-4 h-4" />
              <span>User Management</span>
            </Link>
            <Link
              to="/payment-records"
              className="flex items-center space-x-2 text-black px-3 py-2 rounded-md text-sm font-medium transition-colors"
            >
              <FaCreditCard className="w-4 h-4" />
              <span>Payment Records</span>
            </Link>
            <Link
              to="/"
              className="flex items-center space-x-2 text-black px-3 py-2 rounded-md text-sm font-medium transition-colors"
            >
              <FaHome className="w-4 h-4" />
              <span>Back to Site</span>
            </Link>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h2 className="text-3xl font-bold text-yellow-400 mb-2">Dashboard Overview</h2>
          <p className="text-gray-300">Monitor and manage your hotel booking system</p>
        </motion.div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {adminCards.map((card, index) => (
            <motion.div
              key={card.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-900 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <Link to={card.link} className="block">
                <div className="flex items-center">
                  <div className={`p-3 rounded-full ${card.color} text-black`}>
                    <card.icon className="h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-300">{card.title}</p>
                    <p className="text-2xl font-semibold text-yellow-400">{card.value}</p>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-gray-900 rounded-lg shadow-md p-6"
        >
          <h3 className="text-xl font-semibold text-yellow-400 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link
              to="/users"
              className="flex items-center p-4 border border-yellow-400 rounded-lg hover:bg-yellow-900 hover:border-yellow-300 transition-colors"
            >
              <FaUsers className="w-6 h-6 text-yellow-400 mr-3" />
              <div>
                <h4 className="font-medium text-yellow-400">Manage Users</h4>
                <p className="text-sm text-gray-300">View, edit, and delete user accounts</p>
              </div>
            </Link>
            <Link
              to="/payment-records"
              className="flex items-center p-4 border border-yellow-400 rounded-lg hover:bg-yellow-900 hover:border-yellow-300 transition-colors"
            >
              <FaCreditCard className="w-6 h-6 text-yellow-400 mr-3" />
              <div>
                <h4 className="font-medium text-yellow-400">Payment Records</h4>
                <p className="text-sm text-gray-300">Monitor all payment transactions</p>
              </div>
            </Link>
          </div>
        </motion.div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-gray-900 rounded-lg shadow-md p-6 mt-8"
        >
          <h3 className="text-xl font-semibold text-yellow-400 mb-4">Recent Activity</h3>
          <div className="space-y-4">
            <div className="flex items-center p-3 bg-gray-800 rounded-lg">
              <div className="w-2 h-2 bg-yellow-400 rounded-full mr-3"></div>
              <div>
                <p className="text-sm font-medium text-yellow-400">System Status</p>
                <p className="text-xs text-gray-300">All systems are running normally</p>
              </div>
            </div>
            <div className="flex items-center p-3 bg-gray-800 rounded-lg">
              <div className="w-2 h-2 bg-yellow-400 rounded-full mr-3"></div>
              <div>
                <p className="text-sm font-medium text-yellow-400">Database</p>
                <p className="text-xs text-gray-300">Connected and synchronized</p>
              </div>
            </div>
            <div className="flex items-center p-3 bg-gray-800 rounded-lg">
              <div className="w-2 h-2 bg-yellow-400 rounded-full mr-3"></div>
              <div>
                <p className="text-sm font-medium text-yellow-400">Security</p>
                <p className="text-xs text-gray-300">All security protocols active</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Admin;