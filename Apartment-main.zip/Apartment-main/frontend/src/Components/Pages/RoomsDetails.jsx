import React from "react";
import { Link, useParams } from "react-router-dom";

import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";

import heroImg from "../../assets/about-2.png";
import sectionElement from "../../assets/section-element.png";

import element1 from "../../assets/element-1.png";
import element2 from "../../assets/element-2.png";
import element3 from "../../assets/element-3.png";

import RoomsData from "../../Rooms.json";

import amenit1 from "../../assets/air-conditioning.png";
import amenit2 from "../../assets/wi-fi.png";
import amenit3 from "../../assets/television.png";
import amenit4 from "../../assets/pet.png";
import amenit5 from "../../assets/food.png";
import amenit6 from "../../assets/games.png";
import amenit7 from "../../assets/location.png";

function RoomsDetails() {
  const { id } = useParams();
  const room = RoomsData.find((room) => room.id === id);
  if (!room) {
    return (
      <div className="text-center py-20 text-xl text-white">
        Room not Found?
      </div>
    );
  }

  return (
    <>
      {/* Section Banner */}
      <div className="section-banner mt-5 pt-6 relative flex items-center justify-center bg-gray-900">
        <img
          src={sectionElement}
          className="w-full h-full section-banner-element1 absolute opacity-50"
          alt=""
        />
        <img
          src={sectionElement}
          className="w-full h-full section-banner-element2 absolute opacity-50"
          alt=""
        />
        <img
          src={element1}
          className="w-full h-full section-banner-element3 absolute opacity-50"
          alt=""
        />
        <img
          src={element2}
          className="w-full h-full section-banner-element4 absolute opacity-50"
          alt=""
        />
        <img
          src={element3}
          className="w-full h-full section-banner-element5 absolute opacity-50"
          alt=""
        />

        <div className="section-banner-content flex items-center flex-col text-center z-[55]">
<<<<<<< HEAD
          <h1 className="text-7xl font-semibold text-yellow-400">
            Get your <br /> dream Room
          </h1>
          <div className="mt-10 bg-gray-600 w-[250px] p-2 text-xl rounded text-white">
            <Link to="/" className="text-yellow-400">
              Home
            </Link>{" "}
            &nbsp; / &nbsp;
            <span className="text-gray-300">RoomsDetails</span>
=======
          <h1 className="text-7xl font-semibold">
            Choose your <br /> dream Apartment
          </h1>
          <div className="mt-10 bg-[#d5f1f1] w-[250px] p-2 text-xl rounded">
            <Link to="/">Home</Link> &nbsp; / &nbsp;
            <span className="text-gray-500">ApartmentDetails</span>
>>>>>>> ae8d78ac565e7d8d6ab884dce02f9ff277b44841
          </div>
        </div>
      </div>

      {/* Show Rooms Details */}
      <div className="w-full py-[100px] px-[8%] lg:px-[12%] bg-gray-900">
        <h2 className="text-6xl font-bold mb-4 text-yellow-400 font-bricolage">
          {room.title}
        </h2>
        <div className="flex flex-col lg:flex-row gap-10 items-start">
          {/* Swiper Selection */}
          <div className="w-full lg:w-2/3 p-5 rounded-2xl">
            <Swiper
              spaceBetween={30}
              speed={1000}
              modules={[Pagination]}
              pagination={{ clickable: true }}
              className="w-full h-[420px] bg-gray-600 shadow-lg rounded-xl overflow-hidden custom-swiper"
              style={{ padding: "10px" }}
            >
              {room.photos.map((photo, index) => (
                <SwiperSlide key={index}>
                  <img
                    src={photo}
                    alt={`${room.title} ${index + 1}`}
                    className="w-full h-full object-cover rounded-xl"
                  />
                </SwiperSlide>
              ))}
            </Swiper>
            <div className="py-[50px]">
              <h2 className="text-3xl font-bold my-[20px] text-yellow-400">
                Key features
              </h2>

              <div className="rooms-features grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
                <div className="flex items-center gap-3 bg-gray-600 rounded-xl shadow-md p-4">
                  <img
                    src={amenit1}
                    className="w-[50px] h-[50px] p-3 bg-yellow-100 rounded-md"
                    alt=""
                  />
                  <p className="font-medium text-white text-xl">
                    Air Conditioned
                  </p>
                </div>

                <div className="flex items-center gap-3 bg-gray-600 rounded-xl shadow-md p-4">
                  <img
                    src={amenit2}
                    className="w-[50px] h-[50px] p-3 bg-yellow-100 rounded-md"
                    alt=""
                  />
                  <p className="font-medium text-white text-xl">Free Wi-fi</p>
                </div>

                <div className="flex items-center gap-3 bg-gray-600 rounded-xl shadow-md p-4">
                  <img
                    src={amenit3}
                    className="w-[50px] h-[50px] p-3 bg-yellow-100 rounded-md"
                    alt=""
                  />
                  <p className="font-medium text-white text-xl">Smart TV</p>
                </div>

                <div className="flex items-center gap-3 bg-gray-600 rounded-xl shadow-md p-4">
                  <img
                    src={amenit4}
                    className="w-[50px] h-[50px] p-3 bg-yellow-100 rounded-md"
                    alt=""
                  />
                  <p className="font-medium text-white text-xl">Pet Friendly</p>
                </div>

                <div className="flex items-center gap-3 bg-gray-600 rounded-xl shadow-md p-4">
                  <img
                    src={amenit5}
                    className="w-[50px] h-[50px] p-3 bg-yellow-100 rounded-md"
                    alt=""
                  />
                  <p className="font-medium text-white text-xl">Free Lunch</p>
                </div>

                <div className="flex items-center gap-3 bg-gray-600 rounded-xl shadow-md p-4">
                  <img
                    src={amenit6}
                    className="w-[50px] h-[50px] p-3 bg-yellow-100 rounded-md"
                    alt=""
                  />
                  <p className="font-medium text-white text-xl">Game Room</p>
                </div>
              </div>

              <h2 className="text-3xl font-bold my-[20px] pt-[30px] text-yellow-400">
                Description
              </h2>

              <p className="py-3 text-white" style={{ fontWeight: "300" }}>
                Our apartments are carefully designed to combine modern style
                with everyday comfort. Each unit features contemporary
                interiors, natural lighting, and premium furnishings to create a
                welcoming living space. Whether you're staying short-term or
                long-term, you'll enjoy a home-like atmosphere with cozy
                bedrooms and functional living areas.
              </p>
              <p className="py-3 text-white" style={{ fontWeight: "300" }}>
                Every apartment includes essential amenities such as high-speed
                Wi-Fi, air conditioning, a smart TV, fully equipped kitchen,
                washing machine, and a private bathroom with quality toiletries.
                Some apartments also offer private balconies, scenic city or
                garden views, and upgraded features like spacious lounges or
                dedicated workspaces.
              </p>
              <p className="py-3 text-white" style={{ fontWeight: "300" }}>
                We provide a wide range of apartment types – from compact
                studios and one-bedroom units to family-sized suites and luxury
                penthouses – ensuring the perfect choice for solo travelers,
                couples, families, and business guests. With 24/7 customer
                support, regular housekeeping, and attentive service, your
                apartment stay will be as convenient as it is memorable.
              </p>

              <h2 className="text-3xl font-bold my-[20px] pt-[30px] text-yellow-400">
                Amenities
              </h2>
              <div>
                <div className="flex flex-col lg:flex-row gap-8 items-start mb-5">
                  <div className="w-full lg:w-2/3">
                    <div className="bg-gray-600 p-[40px] flex flex-col rounded-2xl shadow-lg">
                      <img
                        src={amenit1}
                        className="w-[60px] h-[60px] mb-7 p-3 bg-yellow-100 rounded-md"
                        alt=""
                      />
                      <h2 className="text-3xl font-semibold text-yellow-400">
                        Air Conditioned
                      </h2>
                      <p className="mt-3 text-white">
                        Our hotel is situated right on the beach, offering
                        stunning ocean views.
                      </p>
                    </div>
                  </div>

                  <div className="w-full lg:w-2/3">
                    <div className="bg-gray-600 p-[40px] flex flex-col rounded-2xl shadow-lg">
                      <img
                        src={amenit2}
                        className="w-[60px] h-[60px] mb-7 p-3 bg-yellow-100 rounded-md"
                        alt=""
                      />
                      <h2 className="text-3xl font-semibold text-yellow-400">
                        Free Wi-fi
                      </h2>
                      <p className="mt-3 text-white">
                        Our hotel is situated right on the beach, offering
                        stunning ocean views.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col lg:flex-row gap-8 items-start mb-5">
                  <div className="w-full lg:w-2/3">
                    <div className="bg-gray-600 p-[40px] flex flex-col rounded-2xl shadow-lg">
                      <img
                        src={amenit3}
                        className="w-[60px] h-[60px] mb-7 p-3 bg-yellow-100 rounded-md"
                        alt=""
                      />
                      <h2 className="text-3xl font-semibold text-yellow-400">
                        Smart TV
                      </h2>
                      <p className="mt-3 text-white">
                        Our hotel is situated right on the beach, offering
                        stunning ocean views.
                      </p>
                    </div>
                  </div>

                  <div className="w-full lg:w-2/3">
                    <div className="bg-gray-600 p-[40px] flex flex-col rounded-2xl shadow-lg">
                      <img
                        src={amenit7}
                        className="w-[60px] h-[60px] mb-7 p-3 bg-yellow-100 rounded-md"
                        alt=""
                      />
                      <h2 className="text-3xl font-semibold text-yellow-400">
                        Free Transfer
                      </h2>
                      <p className="mt-3 text-white">
                        Our hotel is situated right on the beach, offering
                        stunning ocean views.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <h2 className="text-3xl font-bold my-[20px] pt-[30px]">
                Location
              </h2>
              <div className="w-full rounded-xl overflow-hidden shadow-md">
                <iframe
<<<<<<< HEAD
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63321.33843762818!2d79.8282703!3d6.9319642!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae2594c9c9f3f6f%3A0xa1c8cb1c49f0a2b1!2sPort%20City%20Colombo!5e0!3m2!1sen!2slk!4v1690000000002!5m2!1sen!2slk"
                  width="100%"
                  height="450"
                  style={{ border: 0 }}
                  allowFullScreen={true}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
              <br />
              <div className="w-full rounded-xl overflow-hidden shadow-md">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126327.30872626532!2d80.7214975!3d6.8021585!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae3a3bfc63c2b2d%3A0x9d3b2d69f6c7f3f6!2sHorton%20Plains%20National%20Park!5e0!3m2!1sen!2slk!4v1690000000003!5m2!1sen!2slk"
=======
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126264.47339565857!2d80.7832!3d6.9483!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae173c19decb3b7%3A0x1f67d51d4045e97f!2sNuwara+Eliya!5e0!3m2!1sen!2slk!4v1690000000000!5m2!1sen!2slk"
>>>>>>> ae8d78ac565e7d8d6ab884dce02f9ff277b44841
                  width="100%"
                  height="450"
                  style={{ border: 0 }}
                  allowFullScreen={true}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
          <div className="w-full lg:w-1/3 self-start sticky top-[125px] bg-gray-600 p-8 rounded-2xl shadow-lg flex flex-col gap-6">
            <div className="border-2 border-yellow-400 rounded-2xl px-6 py-4 text-center flex justify-center items-end">
              <h2 className="text-4xl font-bold text-white flex items-start">
                <span className="text-sm"></span> {room.price}
              </h2>
              <p className="text-gray-300 text-sm font-normal ms-4">
                /per night
              </p>
            </div>
            <div className="flex justify-around bg-gray-700 py-3 rounded-xl text-white font-medium text-sm">
              <div className="flex items-center gap-2">
                <i className="ri-user-line text-lg"></i> Per Person: {room.forPerson}
              </div>
              <div className="flex items-center gap-2">
                <i className="ri-aspect-ratio-line text-lg"></i> Size:{" "}
                {room.size}
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-1">
                CHECK-IN
              </label>
              <input
                type="date"
                className="w-full p-3 bg-gray-700 rounded-md outline-none text-white"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1">
                CHECK-OUT
              </label>
              <input
                type="date"
                className="w-full p-3 bg-gray-700 rounded-md outline-none text-white"
              />
            </div>

            <Link to={`/checkout/${room.id}`}>
              <button className="w-full py-3 bg-yellow-400 hover:bg-yellow-500 transition text-black text-lg rounded-full flex items-center justify-center gap-2 mt-4">
                <i className="ri-bookmark-line"></i> BOOK NOW
              </button>
            </Link>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="cta p-[50px] bg-gray-900">
        <div className="py-[100px] rounded-xl bg-gray-600 shadow flex items-center justify-center">
          <div className="section-title text-center space-y-4">
            <span className="bg-gray-700 rounded-full px-5 py-2 font-bricolage tracking-wider uppercase text-yellow-400">
              Call to Action
            </span>
            <h1 className="text-6xl font-semibold text-center text-yellow-400">
              Do you have any Question? <br />
              We are available 24/7
            </h1>
            <div className="flex items-center justify-center py-[30px] gap-2">
              <button className="w-[170px] h-[50px] bg-yellow-400 hover:bg-yellow-500 transition rounded-full text-black">
                <i className="bi bi-envelope pe-2"></i> Get In Touch
              </button>
              <Link to={`/checkout/${room.id}`}>
                <button className="w-[150px] h-[50px] bg-gray-700 hover:bg-gray-800 transition text-white rounded-full">
                  BOOK NOW <i className="ri-arrow-right-line ps-2"></i>
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Recommend */}
      <div className="w-full py-[100px] px-[8%] lg:px-[12%] bg-gray-900">
        <div className="section-title text-start space-y-4">
          <span className="bg-gray-700 rounded-full px-5 py-2 font-bricolage uppercase text-yellow-400">
            Welcome Friend
          </span>
          <h1 className="text-5xl font-semibold text-yellow-400">
            We Recommend
          </h1>
        </div>
        <div className="mt-5 pt-5">
          <Swiper
            slidesPerView={3.5}
            spaceBetween={30}
            loop={true}
            breakpoints={{
              1399: { slidesPerView: 3.5 },
              1199: { slidesPerView: 2.5 },
              991: { slidesPerView: 1 },
              0: { slidesPerView: 1 },
            }}
            style={{ padding: "20px 0" }}
          >
            {RoomsData.map((room) => (
              <SwiperSlide key={room.id}>
                <div className="bg-gray-600 rounded-2xl shadow-md overflow-hidden show-rooms">
                  <div className="relative">
                    <Swiper
                      modules={[Pagination]}
                      pagination={{ clickable: true }}
                      className="w-full h-[280px] custom-swiper"
                    >
                      {room.photos.map((photo, index) => (
                        <SwiperSlide key={index}>
                          <img
                            src={photo}
                            alt={`${room.title} ${index + 1}`}
                            className="w-full h-[280px] object-cover"
                          />
                        </SwiperSlide>
                      ))}
                    </Swiper>
                  </div>
                  <div className="bg-gray-700 flex gap-4 px-4 py-3 text-sm text-white">
                    <span className="flex items-center gap-1">
                      <i className="bg-gray-600 shadow rounded py-1 px-3 ri-user-line"></i>
                      Adults: {room.adults}
                    </span>
                    <span className="flex items-center gap-1">
                      <i className="bg-gray-600 shadow rounded py-1 px-3 ri-aspect-ratio-line"></i>
                      Size: {room.size} m²
                    </span>
                  </div>

                  <Link to={`/rooms/${room.id}`}>
                    <div className="px-6 pt-4 pb-4">
                      <div className="py-4">
                        <h3 className="text-2xl font-semibold mb-1 text-yellow-400">
                          {room.title}
                        </h3>
                        <p className="text-md text-white">{room.description}</p>
                      </div>
                      <div className="border-t border-gray-500 mt-4 pt-4 flex justify-between items-center">
                        <p className="text-lg font-bold text-white">
                          {room.price}
                        </p>
                        <button className="w-12 h-12 bg-yellow-400 hover:bg-yellow-500 rounded-full flex items-center justify-center text-black text-xl">
                          <i className="ri-bookmark-line"></i>
                        </button>
                      </div>
                    </div>
                  </Link>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
    </>
  );
}

export default RoomsDetails;
